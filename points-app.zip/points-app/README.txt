MY POINTS — how to put it online and on her phone
==================================================

1. Put it online (free, about 5 minutes)
   - Go to https://app.netlify.com/signup and create a free account
     (an account keeps the site permanently; without one, drops expire).
   - Go to https://app.netlify.com/drop
   - Unzip points-app.zip, then drag the whole "points-app" folder onto the page.
   - Netlify gives you a link like https://something-random.netlify.app
     (Site settings > Change site name lets you pick a nicer name.)

2. Add it to her phone's home screen
   - iPhone: open the link in Safari > Share button > "Add to Home Screen".
   - Android: open the link in Chrome > ⋮ menu > "Add to Home screen" / "Install app".
   It then opens full-screen like a normal app and works offline.

3. Good to know
   - Points are saved on her phone only. Use Settings (gear) > "Save backup"
     every week or two. "Restore backup" brings it back on a new phone.
   - Deleting the home-screen app or clearing Safari/Chrome website data erases the points.
   - All chores, point values and privileges can be edited in Settings.
   - To update the app later, drag the new folder onto Netlify again
     (Deploys tab > drag & drop). Her points are not affected.
